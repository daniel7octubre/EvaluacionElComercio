<?php 

class ReporteSalarios 
{
    private $empleados = [];

    public function __construct($empleados=[])
    {
        $this->empleados = $empleados;
    }
    /**
    * ReporteSalarios Function
    * Informacion del servicio y testeo
    * @param string $salario_01
    * @param string $salario_02
    * @return array
    */
    public function ReporteSalarios($salario_01,$salario_02){
        
        $empleados = [];

        foreach ($this->empleados as $info_empleado) {
            
            $salario = $info_empleado['salary'];

            $salario = str_replace('$','',$salario);
            $salario = str_replace(',','',$salario);

            if( $salario_01<=$salario && $salario<=$salario_02){
                $empleados[] = $info_empleado;
            }

        }

        return $empleados;

    }
}