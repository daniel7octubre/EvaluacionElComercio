<?php

use Zend\Soap\AutoDiscover;
use Zend\Soap\Server as SoapServer;

require __DIR__ . '/../src/servicio_web/ReporteSalarios.php';

//define("SERVICIO_WEB_URL", "http://localhost:8080/slim/evaluacion.elcomercio/slim.developers.sac/public/servicio_web");

$app->group("/servicio_web",function(){
 
    // wsdl ruta de informacion del servicio
    $this->get("/wsdl",function($request, $response) {

        $base_url = $request->getUri()->getBaseUrl();
        $base_url = $base_url.'/servicio_web';

        $autodiscover = new AutoDiscover();        

        $autodiscover->setClass(new ReporteSalarios($this->empleados))
                     ->setServiceName('Servicio Reporte Salarios')
                     ->setUri($base_url);

        $newResponse = $response->withStatus(200)
                ->withHeader('Content-type', 'application/xml')
                ->write($autodiscover->toXml());
        
        return $newResponse;

    });
 
    // punto de ejecucion del servicio
    $this->post("",function($request){
        
        $base_url = $request->getUri()->getBaseUrl();
        $base_url = $base_url.'/servicio_web';

        $options = array('uri' =>$base_url,'location' => $base_url);
        $server = new SoapServer($base_url."/wsdl",$options);
        $server->setClass(new ReporteSalarios($this->empleados))
            ->handle();
    });

});